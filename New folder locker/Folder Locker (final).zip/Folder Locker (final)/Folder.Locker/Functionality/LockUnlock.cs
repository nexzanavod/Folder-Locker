﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Folder_Locker.Functionality
{
    class LockUnlock
    {
        public LockUnlock()
        {

        }

        private void DummyFile(string folderPath)
        {
            TextWriter textWriter = File.CreateText(folderPath + "\\FolderLock.bat");

            #region Writing File
            {
                textWriter.WriteLine("This is .bat file has been used to hide files or folders,");
                textWriter.WriteLine(" Use the App \"Folder App to unlock them :) \" ");
            }
            #endregion

            textWriter.Close();
        }

        private void CreateBatLockFile(string folderPath)
        {
            TextWriter textWriter = File.CreateText(folderPath + "\\FolderLock.bat");

            #region Writing File
            {
                textWriter.WriteLine("cls");
                textWriter.WriteLine("@ECHO OFF");
                textWriter.WriteLine("title Folder Locker");
                textWriter.WriteLine("@ECHO OFF");
                textWriter.WriteLine();

                textWriter.WriteLine("if EXIST \"Control Panel.{ 21EC2020 - 3AEA - 1069 - A2DD - 08002B30309D}\" goto UNLOCK");
                textWriter.WriteLine("if NOT EXIST Locker goto MDLOCKER");
                textWriter.WriteLine();

                textWriter.WriteLine(":CONFIRM");
                textWriter.WriteLine("echo Are you sure u want to Lock the folder(Y/N)");
                textWriter.WriteLine("set/p \"choice=>\"");
                textWriter.WriteLine("if %choice%==Y goto LOCK");
                textWriter.WriteLine("if %choice%==y goto LOCK");
                textWriter.WriteLine("if %choice%==n goto END");
                textWriter.WriteLine("if %choice%==N goto END");
                textWriter.WriteLine("echo Invalid choice.");
                textWriter.WriteLine("goto CONFIRM");
                textWriter.WriteLine();

                textWriter.WriteLine(":LOCK");
                textWriter.WriteLine("ren Locker \"Control Panel.{ 21EC2020 - 3AEA - 1069 - A2DD - 08002B30309D}\" ");
                textWriter.WriteLine("attrib +h +s \"Control Panel.{ 21EC2020 - 3AEA - 1069 - A2DD - 08002B30309D}\" ");
                textWriter.WriteLine("echo Folder locked");
                textWriter.WriteLine("goto End");
                textWriter.WriteLine();

                textWriter.WriteLine(":UNLOCK");
                textWriter.WriteLine("echo Enter password to Unlock folder");
                textWriter.WriteLine("set/p \"pass=>\"");
                textWriter.WriteLine("if NOT %pass%==1234 goto FAIL");
                textWriter.WriteLine("attrib -h -s \"Control Panel.{ 21EC2020 - 3AEA - 1069 - A2DD - 08002B30309D}\"");
                textWriter.WriteLine("ren \"Control Panel.{ 21EC2020 - 3AEA - 1069 - A2DD - 08002B30309D}\" Locker");
                textWriter.WriteLine("echo Folder Unlocked successfully");
                textWriter.WriteLine("goto End");
                textWriter.WriteLine();

                textWriter.WriteLine(":FAIL");
                textWriter.WriteLine("echo Invalid password");
                textWriter.WriteLine("goto end");
                textWriter.WriteLine();

                textWriter.WriteLine(":MDLOCKER");
                textWriter.WriteLine("md Locker");
                textWriter.WriteLine("echo Locker created successfully");
                textWriter.WriteLine("goto End");
                textWriter.WriteLine();

                textWriter.WriteLine(":End");
            }
            #endregion

            textWriter.Close();
        }

        private ProcessStartInfo ProcessInfo(string folderPath)
        {
            CreateBatLockFile(folderPath);                                   // Update .batFile to be able to unlock when executed

            string batFilePath = "\"" + folderPath + "\\FolderLock.bat" + "\"";            // .bat file path to execute            

            var processInfo = new ProcessStartInfo("cmd.exe", "/c " + batFilePath);   // run windows command line with the input as .bat file path

            // Process Properties
            processInfo.CreateNoWindow = true;                                      // Do not display the cmd line
            processInfo.UseShellExecute = false;
            processInfo.WorkingDirectory = folderPath;                       // Set directory to be where the .bat file is 
            processInfo.RedirectStandardError = true;                               // Error reporting
            processInfo.RedirectStandardOutput = true;                              // Display output
            processInfo.RedirectStandardInput = true;                               // Supply inputs

            return processInfo;
        }

        public void CreateLockerFolder(string folderPath)
        {
            Process process = Process.Start(ProcessInfo(folderPath));         // Create and Start a windows process with the above defined properties
            process.StandardInput.Write("N");                                            // Dummy input

            string output = process.StandardOutput.ReadToEnd();
            string error = process.StandardError.ReadToEnd();

            //MessageBox.Show(string.Format("output : {0}\nerror: {1}", output, error));

            process.Close();

            DummyFile(folderPath);
        }
        
        public void LockFolder(string folderPath)
        {
            Process process = Process.Start(ProcessInfo(folderPath));               // Create and Start a windows process with the above defined properties

            process.StandardInput.Write("Y");                                       // Supply input (AKA -> Lock? = "Yes" )

            string output = process.StandardOutput.ReadToEnd();
            string error = process.StandardError.ReadToEnd();

           // MessageBox.Show(string.Format("out : {0}\nerr: {1}", output, error));

            process.Close();

            DummyFile(folderPath);
        }

        public void UnlockFolder(string folderPath)
        {
            Process process = Process.Start(ProcessInfo(folderPath));   // Create and Start a windows process with the above defined properties

            process.StandardInput.Write("1234");                        // Supply input (AKA -> Password )

            string output = process.StandardOutput.ReadToEnd();
            string error = process.StandardError.ReadToEnd();

           // MessageBox.Show(string.Format("out : {0}\nerr: {1}", output, error));

            process.Close();                                        // Close the Process

            DummyFile(folderPath);
        }
    }
}
